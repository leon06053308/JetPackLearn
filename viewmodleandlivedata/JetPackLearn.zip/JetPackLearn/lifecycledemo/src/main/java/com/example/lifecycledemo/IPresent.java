package com.example.lifecycledemo;

import androidx.lifecycle.DefaultLifecycleObserver;

public interface IPresent extends DefaultLifecycleObserver {
}
