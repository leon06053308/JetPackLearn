package com.example.databindingdemo;

public class StringUtils {

    public static String toUpperCase(String str) {
        return str.toUpperCase();
    }

}
